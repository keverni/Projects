
var config = {
	mode: "fixed_servers",
    rules: {
        singleProxy: {
            scheme: "http",
            host: "185.162.233.234",
            port: parseInt(8000)
        },
        bypassList: []
	}
};

chrome.proxy.settings.set({ value: config, scope: "regular" }, function() { });

function callbackFn(details)
{
	return {
		authCredentials:
		{
			username: "SCBEq8",
			password: "QV6XWw"
		}
	};
}

chrome.webRequest.onAuthRequired.addListener(
	callbackFn,

	{ urls:["<all_urls>"] },
    ['blocking']
);